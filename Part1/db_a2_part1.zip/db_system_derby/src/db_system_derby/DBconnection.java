package db_system_derby;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.derby.shared.common.error.DerbySQLIntegrityConstraintViolationException;

public class DBconnection {
	private static final String DRIVER ="org.apache.derby.jdbc.EmbeddedDriver";

	Connection conn;
	String[] queries;
	Statement statement;
	//PreparedStatement stmt;
	public DBconnection(String JDBC_URL) throws ClassNotFoundException {
		Class.forName(DRIVER);
		try {
			this.conn = DriverManager.getConnection(JDBC_URL);
			conn.setAutoCommit(false);
			if(this.conn!=null) {
				System.out.println("Connection done");
			}
		}
		catch(SQLException e){
			System.err.println("Connection failed");
			System.exit(-1);
		}
	}
	public Connection getConnection() {
		return this.conn;
	}
	public void execute(String command) throws DerbySQLIntegrityConstraintViolationException  
	{
		try
        {
			if(command.equals("Add"))
				statement=conn.createStatement();
			else if (command.equals("Close"))
				statement.close();
			else
			{
				statement.execute(command);
			}
			
        }
        catch (SQLException sqlExcept)
        {
            sqlExcept.printStackTrace();
            
        }
	}
	
	public void addBatch(String query) throws DerbySQLIntegrityConstraintViolationException  
	{
		try
        {
            statement.addBatch(query);
            
        }
        catch (SQLException sqlExcept)
        {
            sqlExcept.printStackTrace();
        }
	}
	public void executeBatch() throws DerbySQLIntegrityConstraintViolationException  
	{
		try
        {
			statement.executeBatch();
			statement.clearBatch();
        }
        catch (SQLException sqlExcept)
        {
            sqlExcept.printStackTrace();
        }
	}

	public void display(String query) throws SQLException {
		Statement stmt = conn.createStatement();
		ResultSet resultSet = stmt.executeQuery(query);
		ResultSetMetaData rsmd = resultSet.getMetaData();
		int columnsNumber = rsmd.getColumnCount();
		while (resultSet.next()) {
		    for (int i = 1; i <= columnsNumber; i++) {
		        //if (i > 1) System.out.print(",  ");
		        //String columnValue = resultSet.getString(i);
		       // System.out.println("column name:" + rsmd.getColumnName(i)+" value: "+columnValue);
		    }
		}
	}
}
