package db_system_derby;

import java.sql.SQLException;

public class db_test {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try {
			if (args[0] != null) {
				String JDBC_URL = "jdbc:derby:" + args[0];// create=true
				DBconnection connectTest = new DBconnection(JDBC_URL);
				// WITH SECONDARY INDEX
				String query = "SELECT RID FROM PARK WHERE (SIGN='2P MTR M-SAT 7:30-20:30' AND AREA = 'Titles')";
				String query1 = "SELECT RID FROM PARK WHERE (SIGN ='2P MTR M-SAT 7:30-20:30')";
				// WITHOUT INDEX
				String query2 = "SELECT RID FROM PARK WHERE RID IN (SELECT DA_ID FROM DA_NAME WHERE DEVICEID = 19711) ";
				String query3= "SELECT RID FROM PARK WHERE IN_VIOLATION='False' ";
				// ---------------------start actual
				// operation-----------------------------------------
				long startTime = System.nanoTime();
				System.out.println("start query 0");
				connectTest.display(query);
				// -------Time measurement!---------
				long endTime = System.nanoTime();
				double estimatedTime = ((double) (endTime - startTime)) / Math.pow(10, 9);
				System.out.println(" time taken = " + estimatedTime + " sec ");
				System.out.println("start query 1");
				startTime = System.nanoTime();
				connectTest.display(query1);
				endTime = System.nanoTime();
				estimatedTime = ((double) (endTime - startTime)) / Math.pow(10, 9);
				System.out.println(" time taken = " + estimatedTime + " sec ");
				// ----------------
				System.out.println("start query 2");
				startTime = System.nanoTime();
				connectTest.display(query2);
				endTime = System.nanoTime();
				estimatedTime = ((double) (endTime - startTime)) / Math.pow(10, 9);
				System.out.println(" time taken = " + estimatedTime + " sec ");
				// ----------------
				System.out.println("start query 3");
				startTime = System.nanoTime();
				connectTest.display(query3);
				endTime = System.nanoTime();
				estimatedTime = ((double) (endTime - startTime)) / Math.pow(10, 9);
				System.out.println(" time taken = " + estimatedTime + " sec ");
				System.out.println("All job completed!");
			} else {
				System.err.println("usage - db_test database_name");
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("usage - db_test database_name");
		}
	}

}
