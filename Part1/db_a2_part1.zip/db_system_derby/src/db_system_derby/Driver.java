package db_system_derby;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.apache.derby.shared.common.error.DerbySQLIntegrityConstraintViolationException;

public class Driver {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, ParseException {
		// TODO Auto-generated method stub
		//-------------------variable&object initialization----------------------------------
		//derbyA1Test
		//derbyA2Test
		String JDBC_URL = "jdbc:derby:derbyA2Test;create=true";//create=true
		DBconnection connectTest = new DBconnection(JDBC_URL);
		ArrayList<Integer> stID = new ArrayList<Integer>();
		String splittedPath=args[0];
		File folder = new File(splittedPath);
		File[] listOfFiles = folder.listFiles();
		System.out.println("Checking splitted files:");
		//---------------------start actual operation-----------------------------------------
		long startTime = System.nanoTime( );
		System.out.print("Start creating table...");
		create(connectTest);
		System.out.print("done"+"\n");
		System.out.println("Start creating Street table...");
		//--------------------looking at each splitted csv file, and load data------------------
		for(int i =0; i <listOfFiles.length;i++)
		{
			System.out.println("Start using splitted files:" +listOfFiles[i].getName());
			insertStreet(connectTest,splittedPath+listOfFiles[i].getName(),stID);
		}
		System.out.print("done"+"\n");
		System.out.println("Start creating DA_NAME table...");
		// the count value is for RID value in DA_NAME and Park table.
		int count=0;
		for(int i =0; i <listOfFiles.length;i++)
		{
			System.out.println("Start using splitted files:" +listOfFiles[i].getName());
			count=insertDA_NAME(connectTest,splittedPath+listOfFiles[i].getName(),count);
		}
		System.out.print("done"+"\n");		
		System.out.println("Start creating PARK table...");
		count =0;
		for(int i =0; i <listOfFiles.length;i++)
		{
			System.out.println("Start using splitted files:" +listOfFiles[i].getName());
			count=insertPark(connectTest,splittedPath+listOfFiles[i].getName(),count);
		}
		System.out.print("done"+"\n");
		//-------Time measurement!---------
		long endTime = System.nanoTime( );
		double estimatedTime = ((double)(endTime-startTime))/Math.pow(10,9);
		System.out.println( " time taken = " + estimatedTime + " sec " ) ;
		//connectTest.display("SELECT * FROM DA_NAME WHERE DEVICEID=19711");
		System.out.println("All job completed!");
	}
	public static void create(DBconnection connectTest) throws DerbySQLIntegrityConstraintViolationException {
		connectTest.execute("Add");
		connectTest.execute("CREATE TABLE STREET(STREETID INTEGER PRIMARY KEY ,"
				+ " STNAME VARCHAR(30))");
		connectTest.execute("CREATE TABLE DA_NAME(DA_ID INTEGER PRIMARY KEY,"
				+ " DEVICEID INTEGER,"
				+ " ARRIVAL_TIME TIMESTAMP)");
		connectTest.execute("CREATE TABLE PARK (RID INTEGER PRIMARY KEY,"
				+ " DEPARTURE_TIME TIMESTAMP,"
				+ " DURATION_SECOND VARCHAR(12),"
				+ " STREET_MARKER VARCHAR(7),"
				+ " SIGN VARCHAR(40),"
				+ " AREA VARCHAR(20),"
				+ " STREET_ID INTEGER REFERENCES STREET(STREETID),"
				+ "BETWEENSTREET1 VARCHAR(30),"
				+ "BETWEENSTREET2 VARCHAR(30),"
				+ "SIDE_OF_ST INTEGER,"
				+ "IN_VIOLATION VARCHAR(5))");
		connectTest.execute("CREATE INDEX SIGN_RID ON PARK(RID, SIGN)");
		connectTest.execute("CREATE INDEX AREA_ID ON PARK(RID, AREA)");
		connectTest.execute("Close");
	}
	
	public static int insertPark(DBconnection connectTest, String filepath, int count) throws ParseException, SQLException{
	  	String csvFile = filepath;
        String line = "";
        String cvsSplitBy = "\\s*,";
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss aa",Locale.US);  // style of format.
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
        	String[] data = line.split(cvsSplitBy);//ignore titles
        	line = br.readLine();//ignore titles
        	Connection c=connectTest.getConnection();
        	PreparedStatement p =c.prepareStatement("INSERT INTO PARK VALUES("
            		//+ "("+"SELECT DA_ID FROM DA_NAME WHERE DEVICEID="+data[0]+"AND ARRIVAL_TIME = TIMESTAMP("+"'"+new Timestamp(arrival.getTime())+"'"+"))"+","
            		+ "?,?,?,?,?,?,?,?,?,?,?)");
            while ((line = br.readLine()) != null) {
                data = line.split(cvsSplitBy);
                java.util.Date myDate = format.parse(data[2]);
                p.setInt(1,count);
        		p.setString(2,new Timestamp(myDate.getTime()).toString());
        		p.setString(3,data[3]);
        		p.setString(4,data[4]);
        		p.setString(5,data[5]);
        		p.setString(6,data[6]);
        		p.setInt(7,Integer.parseInt(data[7]));
        		p.setString(8,data[9].toString());
        		p.setString(9,data[10]);
        		p.setString(10,data[11]);
        		p.setString(11,data[12]);
        		p.addBatch();
                if(count%1000==0)
                {
                	p.clearParameters();
                	c.commit();
                	p.executeBatch();
                }
                count++;
            }
            p.executeBatch();
            c.commit();
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return count;

}
	public static int insertDA_NAME(DBconnection connectTest, String filepath,int count) throws ParseException, SQLException {
	  	String csvFile = filepath;
        String line = "";
        Connection c=connectTest.getConnection();
        PreparedStatement p = c.prepareStatement("INSERT INTO DA_NAME VALUES(?,?,?)" );
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
        	String[] data = line.split(",");//ignore titles
        	line = br.readLine();//ignore titles
            while ((line = br.readLine()) != null) {
            	SimpleDateFormat f =new SimpleDateFormat("dd/MM/yyyy HH:mm:ss aa",Locale.US);
            	Date myDate = new Date();
            	data = line.split(",");
            	myDate = f.parse(data[1]);
            	String time=new Timestamp(myDate.getTime()).toString();
            	p.setInt(1,count);
        		p.setString(2,data[0]);
        		p.setString(3,time);
        		p.addBatch();
                if(count%1000==0)
                {
                	p.executeBatch();
                	c.commit();
                }
                count++;
            }
            p.executeBatch();
            c.commit();
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return count;
}
	
	public static void insertStreet(DBconnection connectTest, String filepath, ArrayList<Integer> stID) throws DerbySQLIntegrityConstraintViolationException {
		  	String csvFile = filepath;
	        String line = "";
	        String cvsSplitBy = ",";
	        connectTest.execute("Add");
	        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
	        	//int count=0;
	        	String[] street = line.split(cvsSplitBy);//ignore titles
	        	line = br.readLine();//ignore titles
	            while ((line = br.readLine()) != null) {
	                street = line.split(cvsSplitBy);
	                if(!stID.contains(Integer.parseInt(street[7])))
	                {
	                connectTest.addBatch("INSERT INTO STREET VALUES("
	                		+ street[7]+","
	                		+"'"+(street[8].contains("'")?street[8].replace("'"," "):street[8])+"'"+")");
	                stID.add(Integer.parseInt(street[7]));
	                }
	            }
	            connectTest.executeBatch();
	            br.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	}

}
