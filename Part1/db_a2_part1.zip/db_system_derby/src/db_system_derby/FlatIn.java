package db_system_derby;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import org.apache.derby.shared.common.error.DerbySQLIntegrityConstraintViolationException;

public class FlatIn {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, ParseException {
		// TODO Auto-generated method stub
		String JDBC_URL = "jdbc:derby:flat;create=true";//create=true
		DBconnection connectTest = new DBconnection(JDBC_URL);
		String splittedPath=args[0];
		File folder = new File(splittedPath);
		File[] listOfFiles = folder.listFiles();
		//---------------------start actual operation-----------------------------------------
		long startTime = System.nanoTime( );
		connectTest.execute("Add");
		connectTest.execute("CREATE TABLE PARK(RID INTEGER PRIMARY KEY,"
				+ "DEVICEID INTEGER,"
				+ "ARRIVAL_TIME TIMESTAMP,"
				+ "DEPARTURE_TIME TIMESTAMP,"
				+ "DURATION_SECOND VARCHAR(12),"
				+ "STREET_MARKER VARCHAR(7),"
				+ "SIGN VARCHAR(40),"
				+ "AREA VARCHAR(20),"
				+ "STREETID INTEGER,"
				+ "STNAME VARCHAR(30),"
				+ "BETWEENSTREET1 VARCHAR(30),"
				+ "BETWEENSTREET2 VARCHAR(30),"
				+ "SIDE_OF_ST INTEGER,"
				+ "IN_VIOLATION VARCHAR(5))");
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss aa",Locale.US);  // style of format.
		int count =0;
        for(int i =0; i <listOfFiles.length;i++)
    		{
        	System.out.println("Start using splitted files:" +listOfFiles[i].getName());
        	try (BufferedReader br = new BufferedReader(new FileReader(splittedPath+listOfFiles[i].getName()))) {
        	String line=new String("");
        	String[] data = line.split(",");//ignore titles
        	line = br.readLine();//ignore titles
        	Connection c=connectTest.getConnection();
        	
        	PreparedStatement p =c.prepareStatement("INSERT INTO PARK VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        	
            while ((line = br.readLine()) != null) {
                data = line.split(",");
                java.util.Date myDate = format.parse(data[1]);
                p.setInt(1,count);
                p.setString(2,data[0]);
                p.setString(3,new Timestamp(myDate.getTime()).toString());
                myDate = format.parse(data[2]);
        		p.setString(4,new Timestamp(myDate.getTime()).toString());
        		p.setString(5,data[3]);
        		p.setString(6,data[4]);
        		p.setString(7,data[5]);
        		p.setString(8,data[6]);
        		p.setInt(9,Integer.parseInt(data[7]));
        		p.setString(10,data[8]);
        		p.setString(11,data[9]);
        		p.setString(12,data[10]);
        		p.setString(13,data[11]);
        		p.setString(14, data[12]);
        		p.addBatch();
        		 if(count%1000==0)
                 {
                 	p.clearParameters();
                 	c.commit();
                 	p.executeBatch();
                 }
                 count++;      
            }
            
            p.executeBatch();
            c.commit();
            br.close();    
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
        long endTime = System.nanoTime( );
		double estimatedTime = ((double)(endTime-startTime))/Math.pow(10,9);
		System.out.println( " time taken = " + estimatedTime + " sec " ) ;
		System.out.println("All job completed!");
        }
	}
	
